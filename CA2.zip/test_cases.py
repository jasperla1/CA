#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jun 26 11:21:39 2019

@author: jasperlammers
"""

import CA


def honeycomb():
    ca = CA.Two_Dim()
    ca.cell_columns = 200
    ca.cell_rows = 150
    ca.colormap = 'Oranges'
    ca.states = 2
    ca.Generate_Random_Part_Cells(0.3,50,50)
    ca.neighbours = 'honeycomb'
    
    ca.Update(200)
    return ca.Animation(200,20)

def beehive():
    ca = CA.Two_Dim()
    ca.cell_columns = 30
    ca.cell_rows = 30
    ca.Generate_Cells()
    ca.colormap = 'Greys'
    ca.states = 3

    ca.neighbours = 'beehive'
    ca.cells[0][ca.cell_rows//2][ca.cell_columns//2] = 1
    ca.Update(8)
    #for i in range(9):
    #    ca.Draw(i)
    return ca.Animation(9,1)

def gun():
    ca = CA.Two_Dim()
    ca.Generate_Cells()
    ca.Add_Gun()
    ca.boundary_conditions = 'periodic'
    ca.states = 2
    ca.neighbours = 'square'
    ca.lives = [2,3]
    ca.born = [3]
    ca.upgrade = []
    ca.Update(400)
    return ca.Animation(400,30)

def rule30():
    ca = CA.One_Dim()
    ca.Generate_Middle_Cells()
    ca.neighbours = 'one'
    ca.Update(30,30)
    return ca.Draw(30)

def rule1069():
    ca = CA.One_Dim()
    ca.cell_columns  = 100
    ca.Generate_Middle_Cells()
    ca.neighbours = 'two'
    ca.Update(100,1069)
    return ca.Draw(100)

def random():
    ca = CA.Two_Dim()
    ca.cell_columns = 100
    ca.cell_rows = 80
    ca.states = 4
    ca.neighbours = 'square'
    ca.interpolation = 'bilinear'
    ca.Generate_Random_Cells(0.3)
    ca.lives = [3,4,13,14,19,20,21]
    ca.born = [3,4,20,23]
    ca.upgrade = [4,5,11,12,13,20,21,22,23]
    ca.Update(100)
    return ca.Animation(100,10)
    
def run():
    print('Cellular Automata')
    
    def step1():
        print('1 or 2 dim (1,2)')
        dim = input()
        if dim == 'c':
            exit
        elif dim == '1' or dim == '2':
            return step2(int(dim))
        else:
            print('Wrong input')
            return step1()
    
    def step2(dim):
        if dim == 1:
            print('number of cells (integer)')
            ncols = input()
            if ncols == 'c':
                exit
            try:
                ncols = int(ncols)
                return step3_1(ncols)
            except:
                print('Wrong input')
                return step2(dim)
        elif dim == 2:
            print('number of rows')
            nrows = input()
            if nrows == 'c':
                exit
            print('number of columns')
            ncols = input()
            if ncols == 'c':
                exit
            try:
                ncols = int(ncols)
                nrows = int(nrows)
                return step3_2(nrows,ncols)
            except:
                print('Wrong input')
                return step2(dim)
    
    def step3_1(ncols):
        print('Random cells, or middle cell (percentage(between 0 and 1), middle)')
        cells = input()
        if cells == 'c':
            exit
        elif cells == 'middle':
            ca = CA.One_Dim()
            ca.cell_columns = ncols
            ca.Generate_Middle_Cells()
            return step3_1b(ca)
        else:
            try:
                cells = int(cells)
                if cells < 1 and cells > 0:
                    ca = CA.One_Dim()
                    ca.cell_columns = ncols
                    ca.Generate_Random_Cells(cells)
                    return step3_1b(ca)
                else:
                    print('Wrong input')
                    return step3_1(ncols)
            except:
                print('Wrong input')
                return step3_1(ncols)
            
            
    def step3_1b(ca):         
        print('rule set for line (1 or 2)')
        ruleset = input()
        if ruleset == 'c':
            exit
        elif ruleset == '1':
            ca.neighbours = 'one'
            return step3_1c(ca)
        elif ruleset == '2':
            ca.neighbours = 'two'
            return step3_1c(ca)
        else:
            print('Wrong input')
            return step3_1b(ca)
        
    def step3_1c(ca):
        print('boundary conditions, (periodic, dirichlet1, dirichlet0)')
        boundary = input()
        if boundary == 'periodic':
            ca.boundary_conditions = 'periodic'
        elif boundary == 'dirichlet1':
            ca.boundary_conditions = 'dirichlet1'
        elif boundary == 'dirichlet0':
            ca.boundary_conditions = 'dirichlet0'
        else:
            print('wrong input')
            return step3_1c(ca)
        print('rule')
        rule = input()
        if rule == 'c':
            exit
        print('timesteps')
        timesteps = input()
        if timesteps == 'c':
            exit
        try:
            rule = int(rule)
            timesteps = int(timesteps)
            ca.Update(timesteps,rule)
            return step4(ca)
        except:
            print('Wrong input')
            return step3_1c(ca)
                
    
    
    def step3_2(nrows,ncols):
        print('Random cells, middle, or gun(for GOL) (percentage(between 0 and 1), middle, gun)')
        cells = input()
        if cells == 'c':
            exit
        elif cells == 'gun':
            ca = CA.Two_Dim()
            ca.cell_columns = ncols
            ca.cell_rows = nrows
            ca.Generate_Cells()
            ca.Add_Gun()
            return step3_2b(ca)
        elif cells == 'middle':
            ca = CA.Two_Dim()
            ca.cell_columns = ncols
            ca.cell_rows = nrows
            ca.Generate_Middle_Cells()
            return step3_2b(ca)
        else:
            try:
                cells = float(cells)
                if cells < 1 and cells > 0:
                    ca = CA.Two_Dim()
                    ca.cell_columns = ncols
                    ca.cell_rows = nrows
                    ca.Generate_Random_Cells(cells)
                    return step3_2b(ca)
                else:
                    print('Wrong input')
                    return step3_2(nrows,ncols)
            except:
                print('Wrong input')
                return step3_2(nrows,ncols)


    def step3_2b(ca):
        print('square, hexagon, beehive, honeycomb, GOL')
        neighbour = input()
        if neighbour == 'c':
            exit
        elif neighbour == 'GOL':
            ca.states = 2 
            ca.born = [3]
            ca.lives = [2,3]
            ca.neighbours = 'square'
            return step3_2d(ca)
        elif neighbour == 'beehive':
            ca.neighbours = 'beehive'
            return step3_2d(ca)
        elif neighbour == 'honeycomb':
            ca.neighbours = 'honeycomb'
            return step3_2d(ca)
        elif neighbour == 'square':
            ca.neighbours = 'square'
            return step3_2c(ca)
        elif neighbour == 'hexagon':
            ca.neighbours = 'hexagon'
            return step3_2c(ca)
        else: 
            print('Wrong input')
            return step3_2b(ca)

    def step3_2c(ca):
        print('states')
        states = input()
        if states == 'c':
            exit
        print('born, split by space')
        born = input().split()
        print('upgrade, split by space')
        upgrade = input().split()
        print('lives, split by space')
        lives = input().split()
        try:
            states = int(states)
            for i in range(len(born)):
                born[i] = int(born[i])
            for i in range(len(upgrade)):
                upgrade[i] = int(upgrade[i])
            for i in range(len(lives)):
                lives[i] = int(lives[i])
                
            ca.lives = lives
            ca.born = born
            ca.upgrade = upgrade
            return step3_2d(ca)
        except: 
            print('wrong input')
            return step3_2c(ca)
        
    def step3_2d(ca):
        print('boudary conditions, (periodic, dirichlet1, dirichlet0)')
        boundary = input()
        if boundary == 'periodic':
            ca.boundary_conditions = 'periodic'
        elif boundary == 'dirichlet1':
            ca.boundary_conditions = 'dirichlet1'
        elif boundary == 'dirichlet0':
            ca.boundary_conditions = 'dirichlet0'
        else:
            print('wrong input')
            return step3_2d(ca)
        print('timesteps')
        timesteps = input()
        if timesteps == 'c':
            exit
        try:
            timesteps = int(timesteps)
            ca.Update(timesteps)
            return step4(ca)
        except:
            print('Wrong input')
            return step3_2d(ca)
        
    def step4(ca):
        print('animation(only for 2 dim), or show timestep (integer or animation)')
        draw = input()
        if draw == 'c':
            exit
        elif draw == 'animation':
            print('number of frames')
            frames = input()
            print('frames per second')
            fps = input()
            try:
                frames = int(frames)
                fps = int(fps)
                return ca.Animation(frames,fps)
            except:
                print('wrong input')
                return step4(ca)
        else:
            try:
                draw = int(draw)
                return ca.Draw(draw)
            except:
                print('wrong input')
                return step4(ca)
            
    x = step1()
    return x
        
        
        
        

            
        
        